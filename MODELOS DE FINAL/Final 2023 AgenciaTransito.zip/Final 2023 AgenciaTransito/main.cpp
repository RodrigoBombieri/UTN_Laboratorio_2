#include <iostream>
using namespace std;
#include "TipoInfraccionArchivo.h"
#include "Examen.h"
#include "MultaArchivo.h"


int main(){

  return 0;
}
